package com.alarma.app

import android.os.SystemClock
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

fun fmtHms(ms: Long): String {
    val s = (ms + 999) / 1000
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

@Composable
fun TimerScreen() {
    val ctx = LocalContext.current
    var end by remember { mutableLongStateOf(Storage.timerEnd(ctx)) }
    var total by remember { mutableLongStateOf(Storage.timerTotal(ctx)) }
    var paused by remember { mutableLongStateOf(Storage.timerPaused(ctx)) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var hh by remember { mutableStateOf("0") }
    var mm by remember { mutableStateOf("5") }
    var ss by remember { mutableStateOf("0") }

    fun refresh() {
        end = Storage.timerEnd(ctx)
        total = Storage.timerTotal(ctx)
        paused = Storage.timerPaused(ctx)
        now = System.currentTimeMillis()
    }
    LaunchedEffect(Unit) {
        while (true) {
            refresh()
            delay(200)
        }
    }

    val active = end > 0 || paused > 0
    val remaining = if (end > 0) maxOf(0L, end - now) else paused

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Temporizador", fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(24.dp))

        if (!active) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TimeField(hh, "horas", Modifier.weight(1f)) { hh = it }
                TimeField(mm, "min", Modifier.weight(1f)) { mm = it }
                TimeField(ss, "seg", Modifier.weight(1f)) { ss = it }
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(1, 5, 10, 30).forEach { p ->
                    Surface(
                        modifier = Modifier.weight(1f).clickable { hh = "0"; mm = p.toString(); ss = "0" },
                        shape = RoundedCornerShape(50),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text("$p min", Modifier.padding(vertical = 10.dp), textAlign = TextAlign.Center)
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
            Button(
                onClick = {
                    val ms = ((hh.toLongOrNull() ?: 0L) * 3600 + (mm.toLongOrNull() ?: 0L) * 60 + (ss.toLongOrNull() ?: 0L)) * 1000
                    if (ms > 0) {
                        Scheduler.timerStart(ctx, ms)
                        refresh()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(64.dp)
            ) { Text("Iniciar", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        } else {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(vertical = 16.dp)) {
                val frac = if (total > 0) (remaining.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
                CircularProgressIndicator(
                    progress = { frac },
                    modifier = Modifier.size(280.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    strokeWidth = 8.dp
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(fmtHms(remaining), fontSize = 44.sp, fontWeight = FontWeight.Light)
                    if (end == 0L) Text("En pausa", color = MaterialTheme.colorScheme.primary)
                }
            }
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { Scheduler.timerCancel(ctx); refresh() },
                    modifier = Modifier.weight(1f).height(56.dp)
                ) { Text("Cancelar") }
                OutlinedButton(
                    onClick = { Scheduler.timerAdd(ctx, 60_000L); refresh() },
                    modifier = Modifier.weight(1f).height(56.dp)
                ) { Text("+1 min") }
                Button(
                    onClick = {
                        if (end > 0) Scheduler.timerPause(ctx) else Scheduler.timerResume(ctx)
                        refresh()
                    },
                    modifier = Modifier.weight(1f).height(56.dp)
                ) { Text(if (end > 0) "Pausar" else "Seguir") }
            }
        }
    }
}

@Composable
fun TimeField(value: String, label: String, modifier: Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter { c -> c.isDigit() }.take(2)) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        textStyle = TextStyle(fontSize = 24.sp, textAlign = TextAlign.Center),
        modifier = modifier
    )
}

// ---------------- Cronómetro ----------------

object SW {
    var running by mutableStateOf(false)
    var startedAt by mutableLongStateOf(0L)
    var accumulated by mutableLongStateOf(0L)
    val laps = mutableStateListOf<Long>()

    fun elapsed(): Long = accumulated + if (running) SystemClock.elapsedRealtime() - startedAt else 0L

    fun toggle() {
        if (running) {
            accumulated = elapsed()
            running = false
        } else {
            startedAt = SystemClock.elapsedRealtime()
            running = true
        }
    }

    fun lap() {
        if (running) laps.add(elapsed())
    }

    fun reset() {
        running = false
        accumulated = 0L
        laps.clear()
    }
}

fun fmtSw(ms: Long): String {
    val h = ms / 3600000
    val m = (ms / 60000) % 60
    val s = (ms / 1000) % 60
    val c = (ms % 1000) / 10
    return if (h > 0) "%d:%02d:%02d.%02d".format(h, m, s, c) else "%02d:%02d.%02d".format(m, s, c)
}

@Composable
fun StopwatchScreen() {
    var t by remember { mutableLongStateOf(SW.elapsed()) }
    LaunchedEffect(SW.running) {
        while (SW.running) {
            t = SW.elapsed()
            delay(30)
        }
        t = SW.elapsed()
    }

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Cronómetro", fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(32.dp))
        Text(fmtSw(t), fontSize = 56.sp, fontWeight = FontWeight.Light)
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (SW.running) {
                OutlinedButton(onClick = { SW.lap() }, modifier = Modifier.weight(1f).height(60.dp)) { Text("Vuelta") }
            } else {
                OutlinedButton(
                    onClick = { SW.reset(); t = 0L },
                    enabled = t > 0L,
                    modifier = Modifier.weight(1f).height(60.dp)
                ) { Text("Reiniciar") }
            }
            Button(onClick = { SW.toggle() }, modifier = Modifier.weight(1f).height(60.dp)) {
                Text(
                    when {
                        SW.running -> "Pausar"
                        t > 0L -> "Reanudar"
                        else -> "Iniciar"
                    },
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        LazyColumn(Modifier.fillMaxWidth()) {
            val laps = SW.laps.toList()
            items(laps.indices.reversed().toList()) { i ->
                val lapMs = laps[i] - (if (i > 0) laps[i - 1] else 0L)
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Vuelta ${i + 1}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(fmtSw(lapMs))
                    Text(fmtSw(laps[i]), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
