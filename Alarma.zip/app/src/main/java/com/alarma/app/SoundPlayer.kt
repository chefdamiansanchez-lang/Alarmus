package com.alarma.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.RingtoneManager
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

object Synth {
    const val SR = 22050

    private fun tone(freq: Double, sec: Double, vol: Double = 0.6, bell: Boolean = false): ShortArray {
        val n = (SR * sec).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / SR
            var env = if (bell) exp(-4.0 * t / sec) else 1.0
            val edge = minOf(i, n - 1 - i) / (SR * 0.005)
            env *= minOf(1.0, edge)
            var s = sin(2 * PI * freq * t)
            if (bell) s = 0.6 * s + 0.3 * sin(2 * PI * freq * 2.76 * t) + 0.2 * sin(2 * PI * freq * 5.4 * t)
            out[i] = (s * env * vol * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }

    private fun silence(sec: Double) = ShortArray((SR * sec).toInt())

    private fun cat(vararg parts: ShortArray): ShortArray {
        var total = 0
        for (a in parts) total += a.size
        val out = ShortArray(total)
        var o = 0
        for (a in parts) {
            a.copyInto(out, o)
            o += a.size
        }
        return out
    }

    fun build(idx: Int): ShortArray = when (idx) {
        0 -> { // Clásico
            val b = cat(tone(880.0, 0.12), silence(0.10))
            cat(b, b, b, b, silence(0.8))
        }
        1 -> { // Amanecer
            cat(
                tone(523.25, 0.6, 0.5, true), tone(659.25, 0.6, 0.5, true),
                tone(783.99, 0.6, 0.5, true), tone(1046.5, 0.9, 0.5, true),
                silence(1.2)
            )
        }
        2 -> { // Campanas
            cat(tone(784.0, 1.0, 0.6, true), tone(659.25, 1.0, 0.6, true), tone(523.25, 1.3, 0.6, true), silence(1.0))
        }
        else -> { // Digital
            val b = cat(tone(1000.0, 0.08), tone(1400.0, 0.08))
            cat(b, b, b, b, b, b, silence(0.5))
        }
    }
}

class SoundPlayer(private val ctx: Context) {
    private var track: AudioTrack? = null
    private var mp: MediaPlayer? = null

    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

    fun start(idx: Int) {
        stop()
        if (idx == 4) {
            try {
                startSystem()
                return
            } catch (e: Exception) {
                try { mp?.release() } catch (x: Exception) {}
                mp = null
            }
        }
        startSynth(if (idx == 4 || idx == Sounds.SOLO_VOZ) 1 else idx)
    }

    private fun startSystem() {
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        val m = MediaPlayer()
        m.setAudioAttributes(attrs)
        m.setDataSource(ctx, uri)
        m.isLooping = true
        m.prepare()
        m.start()
        mp = m
    }

    private fun startSynth(idx: Int) {
        val data = Synth.build(idx)
        val t = AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(Synth.SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(data.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(data, 0, data.size)
        t.setLoopPoints(0, data.size, -1)
        t.play()
        track = t
    }

    fun stop() {
        try { track?.stop() } catch (e: Exception) {}
        try { track?.release() } catch (e: Exception) {}
        track = null
        try { mp?.stop() } catch (e: Exception) {}
        try { mp?.release() } catch (e: Exception) {}
        mp = null
    }
}
