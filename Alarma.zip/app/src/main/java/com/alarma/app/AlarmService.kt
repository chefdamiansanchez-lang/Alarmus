package com.alarma.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AlarmService : Service() {
    companion object {
        const val ACTION_STOP = "com.alarma.app.STOP"
        const val ACTION_SNOOZE = "com.alarma.app.SNOOZE"
        const val ACTION_STOPPED = "com.alarma.app.STOPPED"
        const val CHANNEL = "ring"
        const val NOTIF_ID = 42
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: SoundPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    @Volatile private var pendingText: String? = null
    private var wake: PowerManager.WakeLock? = null
    private var ringing = false
    private var alarmId = 0
    private var kind = "alarm"
    private var soundIdx = 1
    private var notif: Notification? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                finishRinging()
                return START_NOT_STICKY
            }
            ACTION_SNOOZE -> {
                snooze()
                return START_NOT_STICKY
            }
        }
        if (ringing) {
            notif?.let { goForeground(it) }
            return START_NOT_STICKY
        }

        kind = intent?.getStringExtra("kind") ?: "alarm"
        alarmId = intent?.getIntExtra("id", 0) ?: 0
        val alarm = Storage.alarms(this).find { it.id == alarmId }

        val title: String
        val text: String
        if (kind == "timer") {
            title = "Temporizador"
            text = "¡Tiempo terminado!"
        } else {
            title = if (alarm != null && alarm.label.isNotBlank()) alarm.label else "Alarma"
            text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        }
        val n = buildNotification(title, text)
        notif = n
        goForeground(n)
        ringing = true

        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "alarma:ring").apply { acquire(10 * 60 * 1000L) }

        soundIdx = if (kind == "timer") 3 else (alarm?.sound ?: 1)
        val wantsVoice = kind != "timer" && alarm?.voice == true
        if (soundIdx == Sounds.SOLO_VOZ && !wantsVoice) soundIdx = 1

        if (soundIdx != Sounds.SOLO_VOZ) {
            player = SoundPlayer(this)
            player?.start(soundIdx)
        }
        if (alarm?.vibrate != false) {
            vib()?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0))
        }
        if (wantsVoice) prepareVoice(alarm?.label ?: "")

        handler.postDelayed({ finishRinging() }, 5 * 60 * 1000L)
        return START_NOT_STICKY
    }

    private fun goForeground(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL, "Alarma sonando", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.enableVibration(false)
        nm.createNotificationChannel(ch)

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val ringIntent = Intent(this, RingActivity::class.java)
            .putExtra("title", title).putExtra("text", text).putExtra("kind", kind)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val full = PendingIntent.getActivity(this, 1, ringIntent, flags)
        val stopPi = PendingIntent.getService(this, 2, Intent(this, AlarmService::class.java).setAction(ACTION_STOP), flags)
        val snoozePi = PendingIntent.getService(this, 3, Intent(this, AlarmService::class.java).setAction(ACTION_SNOOZE), flags)

        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setFullScreenIntent(full, true)
            .setContentIntent(full)
            .addAction(0, "Detener", stopPi)
        if (kind != "timer") b.addAction(0, "Posponer 10 min", snoozePi)
        return b.build()
    }

    private fun prepareVoice(label: String) {
        tts = TextToSpeech(this) { status ->
            handler.post {
                val t = tts
                if (t != null && status == TextToSpeech.SUCCESS && ringing) {
                    val r = t.setLanguage(Locale("es", "AR"))
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                        t.setLanguage(Locale("es"))
                    }
                    t.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) { handler.post { afterSpeech() } }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { handler.post { afterSpeech() } }
                    })
                    ttsReady = true
                    speakIfReady()
                } else if (ringing && soundIdx == Sounds.SOLO_VOZ) {
                    soundIdx = 1
                    player = SoundPlayer(this).also { it.start(1) }
                }
            }
        }
        Thread {
            val w = Weather.fetch(this)
            pendingText = Announcer.text(label, w)
            handler.post { speakIfReady() }
        }.start()
    }

    private fun speakIfReady() {
        val text = pendingText ?: return
        if (!ttsReady || !ringing || speaking) return
        speaking = true
        player?.stop()
        val r = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ann")
        if (r != TextToSpeech.SUCCESS) afterSpeech()
    }

    private fun afterSpeech() {
        speaking = false
        if (!ringing) return
        if (soundIdx == Sounds.SOLO_VOZ) {
            handler.postDelayed({ speakIfReady() }, 15000)
        } else {
            if (player == null) player = SoundPlayer(this)
            player?.start(soundIdx)
        }
    }

    private fun snooze() {
        if (kind != "timer") {
            Scheduler.set(this, System.currentTimeMillis() + 10 * 60 * 1000L, Scheduler.SNOOZE_CODE, "snooze", alarmId)
        }
        finishRinging()
    }

    private fun finishRinging() {
        cleanup()
        sendBroadcast(Intent(ACTION_STOPPED).setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun cleanup() {
        ringing = false
        speaking = false
        handler.removeCallbacksAndMessages(null)
        player?.stop()
        player = null
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) {}
        tts = null
        try { vib()?.cancel() } catch (e: Exception) {}
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) {}
        wake = null
    }

    @Suppress("DEPRECATION")
    private fun vib(): Vibrator? = try {
        if (Build.VERSION.SDK_INT >= 31) getSystemService(VibratorManager::class.java).defaultVibrator
        else getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    } catch (e: Exception) {
        null
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }
}
