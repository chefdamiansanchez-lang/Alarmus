package com.alarma.app

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RingActivity : ComponentActivity() {
    private val stopped = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ContextCompat.registerReceiver(
            this, stopped, IntentFilter(AlarmService.ACTION_STOPPED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        val title = intent.getStringExtra("title") ?: "Alarma"
        val text = intent.getStringExtra("text") ?: ""
        val isTimer = intent.getStringExtra("kind") == "timer"
        setContent { AlarmaTheme { RingScreen(title, text, isTimer) } }
    }

    override fun onDestroy() {
        try { unregisterReceiver(stopped) } catch (e: Exception) {}
        super.onDestroy()
    }
}

@Composable
fun RingScreen(title: String, text: String, isTimer: Boolean) {
    val ctx = LocalContext.current
    var time by remember { mutableStateOf(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())) }
    LaunchedEffect(Unit) {
        while (true) {
            time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            delay(1000)
        }
    }
    fun send(action: String) {
        ctx.startService(Intent(ctx, AlarmService::class.java).setAction(action))
        (ctx as? Activity)?.finish()
    }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(Modifier.height(24.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (isTimer) "⏳" else "⏰", fontSize = 56.sp)
                Text(time, fontSize = 88.sp, fontWeight = FontWeight.Light, color = MaterialTheme.colorScheme.onBackground)
                Text(title, fontSize = 26.sp, color = MaterialTheme.colorScheme.primary, textAlign = TextAlign.Center)
                Text(text, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
            }
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Button(onClick = { send(AlarmService.ACTION_STOP) }, modifier = Modifier.fillMaxWidth().height(72.dp)) {
                    Text("Detener", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                if (!isTimer) {
                    OutlinedButton(onClick = { send(AlarmService.ACTION_SNOOZE) }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                        Text("Posponer 10 min", fontSize = 16.sp)
                    }
                }
            }
        }
    }
}
