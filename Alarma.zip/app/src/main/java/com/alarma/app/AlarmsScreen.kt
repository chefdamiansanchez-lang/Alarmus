@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.alarma.app

import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay

val DAY_ORDER = listOf(2, 3, 4, 5, 6, 7, 1)
val DAY_SHORT = mapOf(2 to "Lun", 3 to "Mar", 4 to "Mié", 5 to "Jue", 6 to "Vie", 7 to "Sáb", 1 to "Dom")
val DAY_LETTER = mapOf(2 to "L", 3 to "M", 4 to "M", 5 to "J", 6 to "V", 7 to "S", 1 to "D")

fun daysText(d: Set<Int>): String = when {
    d.isEmpty() -> "Una vez"
    d.size == 7 -> "Todos los días"
    else -> DAY_ORDER.filter { it in d }.joinToString(" ") { DAY_SHORT[it] ?: "" }
}

fun nextText(alarms: List<Alarm>): String {
    var best = Long.MAX_VALUE
    alarms.filter { it.enabled }.forEach {
        val t = Scheduler.nextTrigger(it)
        if (t > 0 && t < best) best = t
    }
    if (best == Long.MAX_VALUE) return "Sin alarmas activas"
    val mins = (best - System.currentTimeMillis()) / 60000
    val d = mins / 1440
    val h = (mins % 1440) / 60
    val m = mins % 60
    val parts = mutableListOf<String>()
    if (d > 0) parts.add("$d d")
    if (h > 0) parts.add("$h h")
    if (m > 0 || parts.isEmpty()) parts.add(if (mins == 0L) "menos de 1 min" else "$m min")
    return "Próxima alarma en " + parts.joinToString(" ")
}

@Composable
fun AlarmsScreen() {
    val ctx = LocalContext.current
    var alarms by remember { mutableStateOf(Storage.alarms(ctx)) }
    var editing by remember { mutableStateOf<Alarm?>(null) }
    var isNew by remember { mutableStateOf(false) }
    var fsiOk by remember { mutableStateOf(true) }
    var tick by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            fsiOk = if (Build.VERSION.SDK_INT >= 34) {
                ctx.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
            } else true
            alarms = Storage.alarms(ctx)
            tick = System.currentTimeMillis()
            delay(2000)
        }
    }
    val next = remember(alarms, tick) { nextText(alarms) }

    fun update(a: Alarm) {
        Storage.upsert(ctx, a)
        Scheduler.schedule(ctx, a)
        alarms = Storage.alarms(ctx)
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column {
                    Text("Alarmas", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Text(next, color = MaterialTheme.colorScheme.primary, fontSize = 15.sp)
                }
            }
            if (!fsiOk) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Para que la alarma aparezca sobre la pantalla bloqueada, permití las notificaciones a pantalla completa.", fontSize = 14.sp)
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = {
                                try {
                                    ctx.startActivity(
                                        Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + ctx.packageName))
                                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    )
                                } catch (e: Exception) {
                                }
                            }) { Text("Abrir ajuste") }
                        }
                    }
                }
            }
            if (alarms.isEmpty()) {
                item {
                    Text(
                        "Todavía no hay alarmas. Tocá + para crear una.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 24.dp)
                    )
                }
            }
            items(alarms, key = { it.id }) { a ->
                AlarmCard(
                    a,
                    onToggle = { update(a.copy(enabled = it)) },
                    onClick = { isNew = false; editing = a }
                )
            }
        }
        FloatingActionButton(
            onClick = { isNew = true; editing = Alarm(Storage.newId(), 7, 0) },
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) { Text("+", fontSize = 28.sp, fontWeight = FontWeight.Bold) }
    }

    val e = editing
    if (e != null) {
        AlarmEditor(
            initial = e,
            isNew = isNew,
            onSave = { update(it); editing = null },
            onDelete = {
                Scheduler.cancel(ctx, e.id)
                Storage.delete(ctx, e.id)
                alarms = Storage.alarms(ctx)
                editing = null
            },
            onDismiss = { editing = null }
        )
    }
}

@Composable
fun AlarmCard(a: Alarm, onToggle: (Boolean) -> Unit, onClick: () -> Unit) {
    val alpha = if (a.enabled) 1f else 0.5f
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "%02d:%02d".format(a.hour, a.minute),
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Light,
                    color = (if (a.enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                )
                val sub = (if (a.label.isNotBlank()) a.label + " · " else "") + daysText(a.days)
                Text(sub, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alpha + 0.0f))
                val extras = listOf(
                    if (a.voice) "🗣 Voz" else null,
                    if (a.sound != Sounds.SOLO_VOZ) "🔔 " + Sounds.names[a.sound] else null
                ).filterNotNull().joinToString("  ")
                if (extras.isNotEmpty()) Text(extras, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = a.enabled, onCheckedChange = onToggle)
        }
    }
}

@Composable
fun AlarmEditor(
    initial: Alarm,
    isNew: Boolean,
    onSave: (Alarm) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val tp = rememberTimePickerState(initial.hour, initial.minute, true)
    var label by remember { mutableStateOf(initial.label) }
    var days by remember { mutableStateOf(initial.days) }
    var sound by remember { mutableIntStateOf(initial.sound) }
    var voice by remember { mutableStateOf(initial.voice) }
    var vib by remember { mutableStateOf(initial.vibrate) }
    var previewing by remember { mutableIntStateOf(-1) }
    val player = remember { SoundPlayer(ctx) }

    DisposableEffect(Unit) { onDispose { player.stop() } }
    LaunchedEffect(previewing) {
        if (previewing >= 0) {
            delay(4000)
            player.stop()
            previewing = -1
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(if (isNew) "Nueva alarma" else "Editar alarma", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                TimePicker(state = tp)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it.take(40) },
                    label = { Text("Nombre (opcional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))

                Text("Repetir", modifier = Modifier.fillMaxWidth(), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    DAY_ORDER.forEach { d ->
                        val sel = d in days
                        Box(
                            Modifier.size(40.dp).clip(CircleShape)
                                .background(if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { days = if (sel) days - d else days + d },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                DAY_LETTER[d] ?: "",
                                fontWeight = FontWeight.Bold,
                                color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    TextButton(onClick = { days = emptySet() }) { Text("Una vez") }
                    TextButton(onClick = { days = setOf(2, 3, 4, 5, 6) }) { Text("Lun a Vie") }
                    TextButton(onClick = { days = setOf(1, 2, 3, 4, 5, 6, 7) }) { Text("Todos") }
                }
                Text(daysText(days), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)

                Spacer(Modifier.height(16.dp))
                Text("Sonido", modifier = Modifier.fillMaxWidth(), fontWeight = FontWeight.Bold)
                Sounds.names.forEachIndexed { i, name ->
                    Row(
                        Modifier.fillMaxWidth().clickable { sound = i },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = sound == i, onClick = { sound = i })
                        Text(name, Modifier.weight(1f))
                        if (i != Sounds.SOLO_VOZ) {
                            TextButton(onClick = {
                                if (previewing == i) {
                                    player.stop(); previewing = -1
                                } else {
                                    player.start(i); previewing = i
                                }
                            }) { Text(if (previewing == i) "■ Parar" else "▶ Probar") }
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Voz: día, hora y clima")
                        Text(
                            "Al sonar dice el saludo, la fecha, la hora y el clima.",
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = voice, onCheckedChange = { voice = it })
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Vibrar", Modifier.weight(1f))
                    Switch(checked = vib, onCheckedChange = { vib = it })
                }

                Spacer(Modifier.height(24.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancelar") }
                    Button(
                        onClick = {
                            val v = if (sound == Sounds.SOLO_VOZ) true else voice
                            onSave(Alarm(initial.id, tp.hour, tp.minute, label.trim(), days, true, sound, v, vib))
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Guardar") }
                }
                if (!isNew) {
                    TextButton(onClick = onDelete) {
                        Text("Eliminar alarma", color = MaterialTheme.colorScheme.error)
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
