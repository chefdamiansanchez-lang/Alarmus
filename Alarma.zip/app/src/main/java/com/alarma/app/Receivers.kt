package com.alarma.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getStringExtra("kind") ?: "alarm"
        val id = intent.getIntExtra("id", 0)
        if (kind == "alarm") {
            val alarm = Storage.alarms(context).find { it.id == id } ?: return
            if (!alarm.enabled) return
            if (alarm.days.isEmpty()) {
                Storage.upsert(context, alarm.copy(enabled = false))
            } else {
                Scheduler.schedule(context, alarm, System.currentTimeMillis() + 30_000L)
            }
        } else if (kind == "timer") {
            Storage.setTimer(context, 0, 0, 0)
        }
        ContextCompat.startForegroundService(
            context,
            Intent(context, AlarmService::class.java).putExtras(intent)
        )
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Scheduler.scheduleAll(context)
    }
}
