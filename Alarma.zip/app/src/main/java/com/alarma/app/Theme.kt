package com.alarma.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFFB347),
    onPrimary = Color(0xFF1A1200),
    background = Color(0xFF0B0F14),
    onBackground = Color(0xFFE8EAED),
    surface = Color(0xFF151B23),
    onSurface = Color(0xFFE8EAED),
    surfaceVariant = Color(0xFF1E2630),
    onSurfaceVariant = Color(0xFFA9B1BC),
    secondaryContainer = Color(0xFF2A3340),
    onSecondaryContainer = Color(0xFFFFD79A),
    outline = Color(0xFF3A4452)
)

@Composable
fun AlarmaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
