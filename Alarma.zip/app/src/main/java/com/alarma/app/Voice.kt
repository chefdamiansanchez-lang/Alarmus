package com.alarma.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.roundToInt

object Weather {
    data class Result(val temp: Int, val desc: String)

    fun refreshLocation(ctx: Context): Pair<Double, Double>? {
        val ok = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (ok) {
            try {
                val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                var best: Location? = null
                for (p in lm.getProviders(true)) {
                    try {
                        val l = lm.getLastKnownLocation(p) ?: continue
                        if (best == null || l.time > best.time) best = l
                    } catch (e: SecurityException) {
                    }
                }
                if (best != null) {
                    Storage.setLoc(ctx, best.latitude, best.longitude)
                    return best.latitude to best.longitude
                }
            } catch (e: Exception) {
            }
        }
        return Storage.loc(ctx)
    }

    fun fetch(ctx: Context): Result? {
        val (lat, lon) = refreshLocation(ctx) ?: (-34.6037 to -58.3816) // Buenos Aires por defecto
        return try {
            val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&timezone=auto")
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 6000
            val txt = c.inputStream.bufferedReader().readText()
            c.disconnect()
            val cur = JSONObject(txt).getJSONObject("current")
            Result(cur.getDouble("temperature_2m").roundToInt(), describe(cur.getInt("weather_code")))
        } catch (e: Exception) {
            null
        }
    }

    private fun describe(code: Int): String = when (code) {
        0 -> "despejado"
        1 -> "mayormente despejado"
        2 -> "parcialmente nublado"
        3 -> "nublado"
        45, 48 -> "con niebla"
        in 51..57 -> "con llovizna"
        in 61..67 -> "con lluvia"
        in 71..77 -> "con nevadas"
        in 80..82 -> "con chubascos"
        85, 86 -> "con nevadas"
        in 95..99 -> "con tormenta"
        else -> "variable"
    }
}

object Announcer {
    fun text(label: String, w: Weather.Result?): String {
        val now = Calendar.getInstance()
        val h = now.get(Calendar.HOUR_OF_DAY)
        val m = now.get(Calendar.MINUTE)
        val saludo = when {
            h < 12 -> "Buenos días"
            h < 20 -> "Buenas tardes"
            else -> "Buenas noches"
        }
        val fecha = SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "AR")).format(now.time)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val parte = when {
            h < 12 -> "de la mañana"
            h < 20 -> "de la tarde"
            else -> "de la noche"
        }
        val hora = (if (h12 == 1) "Es la una" else "Son las $h12") +
            (if (m == 0) " en punto" else " y $m") + " $parte"
        val clima = if (w != null) "El clima: ${w.desc}, ${w.temp} grados." else "No pude consultar el clima."
        val et = if (label.isNotBlank()) " Recordatorio: $label." else ""
        return "$saludo. Hoy es $fecha. $hora.$et $clima"
    }
}
