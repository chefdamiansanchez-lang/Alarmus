package com.alarma.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Scheduler {
    const val TIMER_CODE = Int.MAX_VALUE
    const val SNOOZE_CODE = Int.MAX_VALUE - 1

    fun nextTrigger(a: Alarm, from: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance()
        for (offset in 0..7) {
            cal.timeInMillis = from
            cal.add(Calendar.DAY_OF_YEAR, offset)
            cal.set(Calendar.HOUR_OF_DAY, a.hour)
            cal.set(Calendar.MINUTE, a.minute)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            if (cal.timeInMillis <= from) continue
            if (a.days.isEmpty() || a.days.contains(cal.get(Calendar.DAY_OF_WEEK))) return cal.timeInMillis
        }
        return -1L
    }

    private fun am(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pi(ctx: Context, code: Int, kind: String, id: Int): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).putExtra("kind", kind).putExtra("id", id)
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun showPi(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun set(ctx: Context, triggerAt: Long, code: Int, kind: String, id: Int) {
        am(ctx).setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, showPi(ctx)), pi(ctx, code, kind, id))
    }

    fun cancelCode(ctx: Context, code: Int, kind: String, id: Int) {
        am(ctx).cancel(pi(ctx, code, kind, id))
    }

    fun schedule(ctx: Context, a: Alarm, from: Long = System.currentTimeMillis()) {
        cancelCode(ctx, a.id, "alarm", a.id)
        if (!a.enabled) return
        val t = nextTrigger(a, from)
        if (t > 0) set(ctx, t, a.id, "alarm", a.id)
    }

    fun cancel(ctx: Context, id: Int) = cancelCode(ctx, id, "alarm", id)

    fun scheduleAll(ctx: Context) {
        Storage.alarms(ctx).forEach { schedule(ctx, it) }
        val end = Storage.timerEnd(ctx)
        if (end > System.currentTimeMillis()) set(ctx, end, TIMER_CODE, "timer", 0)
        else if (end > 0) Storage.setTimer(ctx, 0, 0, 0)
    }

    // ---- Temporizador ----
    fun timerStart(ctx: Context, ms: Long) {
        val e = System.currentTimeMillis() + ms
        Storage.setTimer(ctx, e, ms, 0)
        set(ctx, e, TIMER_CODE, "timer", 0)
    }

    fun timerPause(ctx: Context) {
        val rem = maxOf(1000L, Storage.timerEnd(ctx) - System.currentTimeMillis())
        cancelCode(ctx, TIMER_CODE, "timer", 0)
        Storage.setTimer(ctx, 0, Storage.timerTotal(ctx), rem)
    }

    fun timerResume(ctx: Context) {
        val rem = Storage.timerPaused(ctx)
        val e = System.currentTimeMillis() + rem
        Storage.setTimer(ctx, e, Storage.timerTotal(ctx), 0)
        set(ctx, e, TIMER_CODE, "timer", 0)
    }

    fun timerAdd(ctx: Context, ms: Long) {
        val end = Storage.timerEnd(ctx)
        val total = Storage.timerTotal(ctx) + ms
        if (end > 0) {
            Storage.setTimer(ctx, end + ms, total, 0)
            set(ctx, end + ms, TIMER_CODE, "timer", 0)
        } else if (Storage.timerPaused(ctx) > 0) {
            Storage.setTimer(ctx, 0, total, Storage.timerPaused(ctx) + ms)
        }
    }

    fun timerCancel(ctx: Context) {
        cancelCode(ctx, TIMER_CODE, "timer", 0)
        Storage.setTimer(ctx, 0, 0, 0)
    }
}
