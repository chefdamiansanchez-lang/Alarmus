package com.alarma.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Alarm(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val label: String = "",
    val days: Set<Int> = emptySet(), // Calendar.DAY_OF_WEEK (1=domingo ... 7=sábado); vacío = una vez
    val enabled: Boolean = true,
    val sound: Int = 1,
    val voice: Boolean = true,
    val vibrate: Boolean = true
)

object Sounds {
    val names = listOf("Clásico", "Amanecer", "Campanas", "Digital", "Tono del teléfono", "Solo voz")
    const val SOLO_VOZ = 5
}

object Storage {
    private fun p(c: Context) = c.getSharedPreferences("alarma", Context.MODE_PRIVATE)

    fun newId(): Int = (System.currentTimeMillis() % 1_000_000_000L).toInt() + 1

    fun alarms(c: Context): List<Alarm> {
        val out = mutableListOf<Alarm>()
        try {
            val arr = JSONArray(p(c).getString("alarms", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val d = mutableSetOf<Int>()
                val da = o.optJSONArray("days")
                if (da != null) for (j in 0 until da.length()) d.add(da.getInt(j))
                out.add(
                    Alarm(
                        o.getInt("id"), o.getInt("hour"), o.getInt("minute"),
                        o.optString("label", ""), d,
                        o.optBoolean("enabled", true), o.optInt("sound", 1),
                        o.optBoolean("voice", true), o.optBoolean("vibrate", true)
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out.sortedWith(compareBy({ it.hour }, { it.minute }))
    }

    fun saveAll(c: Context, list: List<Alarm>) {
        val arr = JSONArray()
        list.forEach { a ->
            val o = JSONObject()
            o.put("id", a.id)
            o.put("hour", a.hour)
            o.put("minute", a.minute)
            o.put("label", a.label)
            o.put("days", JSONArray(a.days.toList()))
            o.put("enabled", a.enabled)
            o.put("sound", a.sound)
            o.put("voice", a.voice)
            o.put("vibrate", a.vibrate)
            arr.put(o)
        }
        p(c).edit().putString("alarms", arr.toString()).apply()
    }

    fun upsert(c: Context, a: Alarm) = saveAll(c, alarms(c).filter { it.id != a.id } + a)
    fun delete(c: Context, id: Int) = saveAll(c, alarms(c).filter { it.id != id })

    // Temporizador
    fun timerEnd(c: Context) = p(c).getLong("t_end", 0L)
    fun timerTotal(c: Context) = p(c).getLong("t_total", 0L)
    fun timerPaused(c: Context) = p(c).getLong("t_paused", 0L)
    fun setTimer(c: Context, end: Long, total: Long, paused: Long) {
        p(c).edit().putLong("t_end", end).putLong("t_total", total).putLong("t_paused", paused).apply()
    }

    // Última ubicación conocida (para el clima)
    fun setLoc(c: Context, lat: Double, lon: Double) {
        p(c).edit().putString("lat", lat.toString()).putString("lon", lon.toString()).apply()
    }

    fun loc(c: Context): Pair<Double, Double>? {
        val la = p(c).getString("lat", null)?.toDoubleOrNull()
        val lo = p(c).getString("lon", null)?.toDoubleOrNull()
        return if (la != null && lo != null) la to lo else null
    }
}
